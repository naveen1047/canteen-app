package com.naveen.canteenapp.login.service;

public interface LoginService {
    boolean login(String id, String password);

    boolean isLoggedIn(String id);

    boolean logout(String id);
}
