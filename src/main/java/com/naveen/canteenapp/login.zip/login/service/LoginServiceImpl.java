package com.naveen.canteenapp.login.service;

import com.naveen.canteenapp.login.dao.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoginServiceImpl implements LoginService {
    private UserRepo userRepo;
    private List<String> loggedUser;

    @Autowired
    public LoginServiceImpl(final UserRepo userRepo) {
        this.userRepo = userRepo;
        loggedUser = new ArrayList<>();
    }

    @Override
    public boolean login(String id, String password) {
        return userRepo.getUsers().stream()
                    .anyMatch(f -> {
                        if (f.getId().equals(id) && f.getPassword().equals(password)){
                            loggedUser.add(id);
                            return true;
                        }
                        return false;
                    });
    }

    @Override
    public boolean isLoggedIn(String id) {
        return loggedUser.contains(id);
    }

    @Override
    public boolean logout(String id) {
        loggedUser.remove(id);
        return true;
    }
}
