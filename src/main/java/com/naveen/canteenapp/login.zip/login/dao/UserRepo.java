package com.naveen.canteenapp.login.dao;

import com.naveen.canteenapp.login.domain.User;
import lombok.Getter;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Getter
@Repository
public class UserRepo {
    List<User> users = new ArrayList<>();

    UserRepo() {
        populateData();
    }

    private void populateData() {
        for (int i = 0; i < 47; i++) {
            String id = i > 9 ? "20MCM0" + i : "20MCM00" + i;
            String password = id;
            users.add(new User(id, password));
        }
    }
}
