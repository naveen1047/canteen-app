package com.naveen.canteenapp.login.controller;

import com.naveen.canteenapp.login.domain.User;
import com.naveen.canteenapp.login.service.LoginService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class LoginController {

    private final LoginService loginService;

    public LoginController(final LoginService loginService) {
        this.loginService = loginService;
    }

    @GetMapping("/login")
    ResponseEntity<String> login(@RequestBody User user) {
        boolean res = loginService.login(user.getId(), user.getPassword());
        if (res) {
            return ResponseEntity.ok(user.getId());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_EXTENDED)
                    .body("Id or password incorrect");
        }
    }

    @GetMapping("/isLoggedIn")
    ResponseEntity<Boolean> isLoggedIn(@RequestBody User user) {
        return ResponseEntity.ok(loginService.isLoggedIn(user.getId()));
    }

    @GetMapping("/logout")
    boolean logout(@RequestBody User user) {
        return loginService.logout(user.getId());
    }
}
